"""Build an offline teaching exercise from editable cases and the existing Sora font."""
from pathlib import Path
import base64
import json

HERE = Path(__file__).resolve().parent
WORKSPACE_FONTS = HERE.parents[2] / 'a-samadi.com/ahmadreza-smdi.github.io/assets/fonts'

def build():
    cases = json.loads((HERE / 'cases.json').read_text())
    assert len(cases) == 6 and len({c['id'] for c in cases}) == 6
    for c in cases:
        assert len(c['choices']) == 3 and c['preferred'] in range(3)
        assert c['source'].startswith('https://a-samadi.com/writing/')
        assert all(option['text'] and option['feedback'] for option in c['choices'])
    font = HERE / 'sora-latin-wght.woff2'
    licence = HERE / 'LICENSE-Sora.txt'
    if not font.exists():
        font.write_bytes((WORKSPACE_FONTS / 'sora-latin-wght.woff2').read_bytes())
    notice = licence.read_text() if licence.exists() else (WORKSPACE_FONTS / 'OFL.txt').read_text()
    template = (HERE / 'template.html').read_text()
    output = template.replace('__FONT__', base64.b64encode(font.read_bytes()).decode())
    assert '</script' not in notice.lower(), 'Font licence must be embedded without changing its bytes'
    output = output.replace('__FONT_NOTICE__', notice)
    output = output.replace('__CASES__', json.dumps(cases, ensure_ascii=False).replace('<', '\\u003c'))
    assert '__FONT__' not in output and '__CASES__' not in output
    (HERE / 'index.html').write_text(output)
    (HERE / 'LICENSE-Sora.txt').write_text(notice)

if __name__ == '__main__':
    build()
