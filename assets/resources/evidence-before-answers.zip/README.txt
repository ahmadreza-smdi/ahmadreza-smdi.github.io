EVIDENCE BEFORE ANSWERS
An original educational exercise for Ahmadreza Samadi's personal brand.

Open index.html in a browser. It works offline; the Sora font and all six cases
are embedded. The only external navigation happens if a reader chooses an
author/article link. There are no accounts, analytics, trackers or saved answers.

New format: six branching practice cases, eighteen answer-specific explanations,
and a final set of reusable review questions. Existing articles and worksheets
are reading sources, not replaced or republished here. Every case and number is
fictional. This is not a company result, benchmark or professional assessment.

Editable source: cases.json, template.html and build.py. Run Python 3 build.py
to rebuild after editing. The original website Sora font is included, so the
source package can rebuild offline outside the workspace. The delivered
index.html needs no build step or dependencies. The complete Sora OFL notice is preserved
in LICENSE-Sora.txt and embedded in the HTML. Original exercise content has no
blanket reuse licence assigned here.

Status: complete local teaching asset; not deployed or scheduled. No new public
URL, social post, native schedule, email, outreach or account was created.
